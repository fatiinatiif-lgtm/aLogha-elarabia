import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'design.dart';
import 'screens/splash_screen.dart';

/// يحمل حالة الوضع الداكن ويحفظها في الجهاز.
final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

Future<void> setDarkMode(bool dark) async {
  themeNotifier.value = dark ? ThemeMode.dark : ThemeMode.light;
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool('dark', dark);
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  themeNotifier.value =
      (prefs.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
  await loadDesign();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppDesign>(
      valueListenable: designNotifier,
      builder: (context, design, _) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeNotifier,
        builder: (context, mode, _) {
          return MaterialApp(
            title: 'مكتبة اللغة العربية',
            debugShowCheckedModeBanner: false,
            themeMode: mode,
            theme: buildTheme(design, Brightness.light),
            darkTheme: buildTheme(design, Brightness.dark),
            builder: (context, child) => Directionality(
                textDirection: TextDirection.rtl, child: child!),
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}
