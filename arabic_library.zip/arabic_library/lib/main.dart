import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/splash_screen.dart';

/// يحمل حالة الوضع الداكن ويحفظها في الجهاز.
final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

Future<void> setDarkMode(bool dark) async {
  themeNotifier.value = dark ? ThemeMode.dark : ThemeMode.light;
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool('dark', dark);
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  themeNotifier.value =
      (prefs.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, mode, _) {
        return MaterialApp(
          title: 'مكتبة اللغة العربية',
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: _light,
            scaffoldBackgroundColor: _light.surface,
            appBarTheme: AppBarTheme(
              centerTitle: true,
              backgroundColor: _light.surface,
              foregroundColor: _light.onSurface,
              elevation: 0,
            ),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: _dark,
            scaffoldBackgroundColor: _dark.surface,
            appBarTheme: AppBarTheme(
              centerTitle: true,
              backgroundColor: _dark.surface,
              foregroundColor: _dark.onSurface,
              elevation: 0,
            ),
          ),
          builder: (context, child) =>
              Directionality(textDirection: TextDirection.rtl, child: child!),
          home: const SplashScreen(),
        );
      },
    );
  }
}

// ألوان مأخوذة من أيقونة التطبيق: أسود، رمادي داكن، رمادي فاتح، كريمي
const _light = ColorScheme(
  brightness: Brightness.light,
  primary: Color(0xFF111111),
  onPrimary: Color(0xFFEFE7DF),
  primaryContainer: Color(0xFFD9D9D9),
  onPrimaryContainer: Color(0xFF111111),
  secondary: Color(0xFF535353),
  onSecondary: Color(0xFFEFE7DF),
  error: Color(0xFFB3261E),
  onError: Colors.white,
  surface: Color(0xFFEFE7DF),
  onSurface: Color(0xFF111111),
  surfaceContainerHighest: Color(0xFFE0D8CF),
);

const _dark = ColorScheme(
  brightness: Brightness.dark,
  primary: Color(0xFFEFE7DF),
  onPrimary: Color(0xFF111111),
  primaryContainer: Color(0xFF535353),
  onPrimaryContainer: Color(0xFFEFE7DF),
  secondary: Color(0xFFD9D9D9),
  onSecondary: Color(0xFF111111),
  error: Color(0xFFF2B8B5),
  onError: Color(0xFF601410),
  surface: Color(0xFF0A0A0A),
  onSurface: Color(0xFFEFE7DF),
  surfaceContainerHighest: Color(0xFF262626),
);
