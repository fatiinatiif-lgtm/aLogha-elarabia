import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// علامة توقف داخل كتاب.
class Bookmark {
  final String id;
  final int page; // رقم الصفحة (يبدأ من 1)
  final String name;
  final int ts;
  const Bookmark({
    required this.id,
    required this.page,
    required this.name,
    required this.ts,
  });

  Map<String, dynamic> toJson() =>
      {'id': id, 'page': page, 'name': name, 'ts': ts};

  factory Bookmark.fromJson(Map<String, dynamic> j) => Bookmark(
        id: j['id'] as String,
        page: (j['page'] as num).toInt(),
        name: (j['name'] as String?) ?? '',
        ts: (j['ts'] as num?)?.toInt() ?? 0,
      );

  Bookmark copyWith({String? name}) =>
      Bookmark(id: id, page: page, name: name ?? this.name, ts: ts);
}

/// حفظ العلامات في الجهاز: عدد غير محدود من العلامات لكل كتاب.
class BookmarksService {
  static const _prefix = 'bm:';

  static List<Bookmark> _decode(String? raw) {
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = (json.decode(raw) as List)
          .map((e) => Bookmark.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
      list.sort((a, b) => a.page.compareTo(b.page));
      return list;
    } catch (_) {
      return [];
    }
  }

  static Future<List<Bookmark>> of(String bookPath) async {
    final prefs = await SharedPreferences.getInstance();
    return _decode(prefs.getString('$_prefix$bookPath'));
  }

  static Future<void> _save(String bookPath, List<Bookmark> list) async {
    final prefs = await SharedPreferences.getInstance();
    if (list.isEmpty) {
      await prefs.remove('$_prefix$bookPath');
    } else {
      await prefs.setString('$_prefix$bookPath',
          json.encode(list.map((b) => b.toJson()).toList()));
    }
  }

  static Future<void> add(String bookPath, int page, String name) async {
    final list = await of(bookPath);
    list.add(Bookmark(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      page: page,
      name: name,
      ts: DateTime.now().millisecondsSinceEpoch,
    ));
    await _save(bookPath, list);
  }

  static Future<void> rename(String bookPath, String id, String name) async {
    final list = await of(bookPath);
    final updated =
        list.map((b) => b.id == id ? b.copyWith(name: name) : b).toList();
    await _save(bookPath, updated);
  }

  static Future<void> remove(String bookPath, String id) async {
    final list = await of(bookPath);
    list.removeWhere((b) => b.id == id);
    await _save(bookPath, list);
  }

  /// كل العلامات في كل الكتب: مسار الكتاب ← علاماته.
  static Future<Map<String, List<Bookmark>>> all() async {
    final prefs = await SharedPreferences.getInstance();
    final result = <String, List<Bookmark>>{};
    for (final key in prefs.getKeys()) {
      if (!key.startsWith(_prefix)) continue;
      final list = _decode(prefs.getString(key));
      if (list.isNotEmpty) result[key.substring(_prefix.length)] = list;
    }
    return result;
  }
}

/// ملحوظة حرة.
class Note {
  final String id;
  final String title;
  final String text;
  final int ts;
  const Note({
    required this.id,
    required this.title,
    required this.text,
    required this.ts,
  });

  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'text': text, 'ts': ts};

  factory Note.fromJson(Map<String, dynamic> j) => Note(
        id: j['id'] as String,
        title: (j['title'] as String?) ?? '',
        text: (j['text'] as String?) ?? '',
        ts: (j['ts'] as num?)?.toInt() ?? 0,
      );
}

class NotesService {
  static const _key = 'notes';

  static Future<List<Note>> all() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = (json.decode(raw) as List)
          .map((e) => Note.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
      list.sort((a, b) => b.ts.compareTo(a.ts));
      return list;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<Note> list) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, json.encode(list.map((n) => n.toJson()).toList()));
  }

  static String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  /// يضيف الملحوظة أو يحدّثها إن كانت موجودة.
  static Future<void> save(Note note) async {
    final list = await all();
    final i = list.indexWhere((n) => n.id == note.id);
    if (i >= 0) {
      list[i] = note;
    } else {
      list.add(note);
    }
    await _write(list);
  }

  static Future<void> remove(String id) async {
    final list = await all();
    list.removeWhere((n) => n.id == id);
    await _write(list);
  }
}
