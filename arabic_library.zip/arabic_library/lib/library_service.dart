import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Section {
  final String id; // اسم المجلد داخل assets/books
  final String title;
  final IconData icon;
  final Color color;
  const Section(this.id, this.title, this.icon, this.color);
}

const List<Section> sections = [
  Section('nahw', 'النحو', Icons.account_tree_rounded, Color(0xFF535353)),
  Section('sarf', 'الصرف', Icons.transform_rounded, Color(0xFF535353)),
  Section('balagha', 'البلاغة', Icons.auto_awesome_rounded, Color(0xFF535353)),
  Section('arud', 'العروض', Icons.graphic_eq_rounded, Color(0xFF535353)),
  Section('adab', 'الأدب العربي', Icons.menu_book_rounded, Color(0xFF535353)),
  Section('fiqh_lugha', 'فقه اللغة', Icons.translate_rounded, Color(0xFF535353)),
];

class Book {
  final String path; // مسار الملف داخل التطبيق
  final String title;
  final Section section;
  const Book(this.path, this.title, this.section);
}

class LibraryService {
  static List<Book>? _cache;

  /// يقرأ كل ملفات PDF الموجودة داخل assets/books تلقائياً.
  static Future<List<Book>> all() async {
    if (_cache != null) return _cache!;
    final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
    // أسماء الكتب الحقيقية (يكتبها ملف البيلد لأن أسماء الملفات الطويلة تفشل البناء)
    Map<String, dynamic> titles = {};
    try {
      titles = json.decode(await rootBundle.loadString('assets/books/titles.json'))
          as Map<String, dynamic>;
    } catch (_) {}
    final books = <Book>[];
    for (final key in manifest.listAssets()) {
      if (!key.startsWith('assets/books/')) continue;
      if (!key.toLowerCase().endsWith('.pdf')) continue;
      final parts = key.split('/');
      if (parts.length < 4) continue;
      final section = sections.where((s) => s.id == parts[2]);
      if (section.isEmpty) continue;
      var name = (titles[key] as String?) ?? '';
      if (name.isEmpty) {
        name = parts.last;
        if (name.contains('%')) {
          try {
            name = Uri.decodeFull(name);
          } catch (_) {}
        }
        name = name.substring(0, name.length - 4).replaceAll('_', ' ').trim();
      }
      books.add(Book(key, name, section.first));
    }
    books.sort((a, b) => a.title.compareTo(b.title));
    _cache = books;
    return books;
  }

  /// كتب القسم بالترتيب الذي اختارته المستخدمة (والكتب الجديدة تُضاف في الآخر).
  static Future<List<Book>> booksOf(Section s) async {
    final books = (await all()).where((b) => b.section.id == s.id).toList();
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('order:${s.id}') ?? const [];
    if (saved.isEmpty) return books;
    final rank = {for (var i = 0; i < saved.length; i++) saved[i]: i};
    final ordered = books.where((b) => rank.containsKey(b.path)).toList()
      ..sort((a, b) => rank[a.path]!.compareTo(rank[b.path]!));
    return [...ordered, ...books.where((b) => !rank.containsKey(b.path))];
  }

  static Future<void> saveOrder(Section s, List<Book> books) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('order:${s.id}', books.map((b) => b.path).toList());
  }

  /// يرجّع الترتيب الأصلي (أبجدي).
  static Future<void> resetOrder(Section s) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('order:${s.id}');
  }

  static String _normalize(String t) => t
      .replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '')
      .replaceAll(RegExp(r'[إأآٱ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .toLowerCase();

  /// البحث في عناوين كل الكتب.
  static Future<List<Book>> search(String query) async {
    final q = _normalize(query.trim());
    if (q.isEmpty) return [];
    return (await all())
        .where((b) => _normalize(b.title).contains(q))
        .toList();
  }
}
