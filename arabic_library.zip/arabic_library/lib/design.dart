import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// طريقة عرض الأقسام في الشاشة الرئيسية.
enum SectionLayout { chips, grid, list, carousel }

/// شكل بطاقة الكتاب.
enum BookTileStyle { card, outlined, flat }

/// تصميم كامل للتطبيق: ألوان + شكل البطاقات + طريقة ترتيب العناصر.
class AppDesign {
  final String id;
  final String name;
  final String description;
  final SectionLayout sectionLayout;
  final BookTileStyle bookTile;
  final double radius;
  final ColorScheme light;
  final ColorScheme dark;
  const AppDesign({
    required this.id,
    required this.name,
    required this.description,
    required this.sectionLayout,
    required this.bookTile,
    required this.radius,
    required this.light,
    required this.dark,
  });
}

/// يمرّر خصائص التصميم لكل الشاشات عبر الـ Theme.
class DesignStyle extends ThemeExtension<DesignStyle> {
  final SectionLayout sectionLayout;
  final BookTileStyle bookTile;
  final double radius;
  const DesignStyle(this.sectionLayout, this.bookTile, this.radius);

  @override
  DesignStyle copyWith(
          {SectionLayout? sectionLayout,
          BookTileStyle? bookTile,
          double? radius}) =>
      DesignStyle(sectionLayout ?? this.sectionLayout,
          bookTile ?? this.bookTile, radius ?? this.radius);

  @override
  DesignStyle lerp(ThemeExtension<DesignStyle>? other, double t) => this;

  static DesignStyle of(BuildContext context) =>
      Theme.of(context).extension<DesignStyle>() ??
      const DesignStyle(SectionLayout.chips, BookTileStyle.card, 16);
}

ColorScheme _seeded(Color seed, Brightness b,
    {Color? primary, Color? surface, Color? container}) {
  final base = ColorScheme.fromSeed(seedColor: seed, brightness: b);
  return base.copyWith(
    primary: primary,
    surface: surface,
    surfaceContainerHighest: container,
  );
}

// ───────────────────────── التصميمات المتاحة ─────────────────────────
final List<AppDesign> designs = [
  // 1) الكلاسيكي: الألوان الأصلية (أسود/رمادي/كريمي) + أقسام على شكل أزرار
  const AppDesign(
    id: 'classic',
    name: 'الكلاسيكي',
    description: 'أقسام على شكل أزرار صغيرة، وبطاقات ناعمة',
    sectionLayout: SectionLayout.chips,
    bookTile: BookTileStyle.card,
    radius: 18,
    light: ColorScheme(
      brightness: Brightness.light,
      primary: Color(0xFF111111),
      onPrimary: Color(0xFFEFE7DF),
      primaryContainer: Color(0xFFD9D9D9),
      onPrimaryContainer: Color(0xFF111111),
      secondary: Color(0xFF535353),
      onSecondary: Color(0xFFEFE7DF),
      error: Color(0xFFB3261E),
      onError: Colors.white,
      surface: Color(0xFFEFE7DF),
      onSurface: Color(0xFF111111),
      surfaceContainerHighest: Color(0xFFE0D8CF),
    ),
    dark: ColorScheme(
      brightness: Brightness.dark,
      primary: Color(0xFFEFE7DF),
      onPrimary: Color(0xFF111111),
      primaryContainer: Color(0xFF535353),
      onPrimaryContainer: Color(0xFFEFE7DF),
      secondary: Color(0xFFD9D9D9),
      onSecondary: Color(0xFF111111),
      error: Color(0xFFF2B8B5),
      onError: Color(0xFF601410),
      surface: Color(0xFF0A0A0A),
      onSurface: Color(0xFFEFE7DF),
      surfaceContainerHighest: Color(0xFF262626),
    ),
  ),
  // 2) الزمرد: أخضر + أقسام شبكة بطاقات كبيرة
  AppDesign(
    id: 'emerald',
    name: 'الزمرد',
    description: 'أقسام كبطاقات كبيرة في شبكة، ألوان خضراء هادئة',
    sectionLayout: SectionLayout.grid,
    bookTile: BookTileStyle.card,
    radius: 26,
    light: _seeded(const Color(0xFF1B6B4A), Brightness.light,
        primary: const Color(0xFF14573B),
        surface: const Color(0xFFF3F8F4),
        container: const Color(0xFFDCEBE1)),
    dark: _seeded(const Color(0xFF1B6B4A), Brightness.dark,
        primary: const Color(0xFF7FD1A8),
        surface: const Color(0xFF0B1511),
        container: const Color(0xFF1B2B23)),
  ),
  // 3) الملكي: كحلي وذهبي + أقسام قائمة طولية + إطارات رفيعة
  AppDesign(
    id: 'royal',
    name: 'الملكي',
    description: 'قائمة طولية أنيقة بإطارات رفيعة، كحلي وذهبي',
    sectionLayout: SectionLayout.list,
    bookTile: BookTileStyle.outlined,
    radius: 8,
    light: _seeded(const Color(0xFF1C2E5A), Brightness.light,
        primary: const Color(0xFF1C2E5A),
        surface: const Color(0xFFFBF7EC),
        container: const Color(0xFFF0E6C8)),
    dark: _seeded(const Color(0xFF1C2E5A), Brightness.dark,
        primary: const Color(0xFFE2C16B),
        surface: const Color(0xFF0C1326),
        container: const Color(0xFF1A2342)),
  ),
  // 4) الرمال: دافئ + أقسام تتحرك أفقياً + كتب بلا بطاقات
  AppDesign(
    id: 'sand',
    name: 'الرمال',
    description: 'أقسام تتصفحينها أفقياً، وكتب في قائمة مفتوحة',
    sectionLayout: SectionLayout.carousel,
    bookTile: BookTileStyle.flat,
    radius: 22,
    light: _seeded(const Color(0xFF9A5B2E), Brightness.light,
        primary: const Color(0xFF8A4B22),
        surface: const Color(0xFFFAF3EA),
        container: const Color(0xFFEEDCC8)),
    dark: _seeded(const Color(0xFF9A5B2E), Brightness.dark,
        primary: const Color(0xFFE3A878),
        surface: const Color(0xFF17100B),
        container: const Color(0xFF2A1E15)),
  ),
];

AppDesign designById(String? id) =>
    designs.firstWhere((d) => d.id == id, orElse: () => designs.first);

final ValueNotifier<AppDesign> designNotifier = ValueNotifier(designs.first);

Future<void> setDesign(AppDesign d) async {
  designNotifier.value = d;
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('design', d.id);
}

Future<void> loadDesign() async {
  final prefs = await SharedPreferences.getInstance();
  designNotifier.value = designById(prefs.getString('design'));
}

ThemeData buildTheme(AppDesign d, Brightness b) {
  final cs = b == Brightness.light ? d.light : d.dark;
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    scaffoldBackgroundColor: cs.surface,
    appBarTheme: AppBarTheme(
      centerTitle: true,
      backgroundColor: cs.surface,
      foregroundColor: cs.onSurface,
      elevation: 0,
    ),
    extensions: [DesignStyle(d.sectionLayout, d.bookTile, d.radius)],
  );
}
