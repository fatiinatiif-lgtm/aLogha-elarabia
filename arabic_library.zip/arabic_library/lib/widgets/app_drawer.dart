import 'package:flutter/material.dart';
import '../screens/about_screen.dart';
import '../screens/arabic_library_screen.dart';
import '../screens/settings_screen.dart';

class AppDrawer extends StatelessWidget {
  /// 'home' | 'library' | 'settings' | 'about'
  final String current;
  const AppDrawer({super.key, required this.current});

  void _go(BuildContext context, String id, Widget? page) {
    Navigator.of(context).pop(); // يغلق القائمة
    if (id == current) return;
    if (id == 'home') {
      Navigator.of(context).popUntil((r) => r.isFirst);
      return;
    }
    // نرجع للرئيسية أولاً حتى لا تتراكم الشاشات
    Navigator.of(context).popUntil((r) => r.isFirst);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page!));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget item(String id, IconData icon, String label, Widget? page) {
      return ListTile(
        leading: Icon(icon),
        title: Text(label, style: const TextStyle(fontSize: 17)),
        selected: current == id,
        selectedTileColor: cs.primaryContainer.withOpacity(0.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: () => _go(context, id, page),
      );
    }

    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [cs.primary, cs.primary.withOpacity(0.7)],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white24,
                    child: Icon(Icons.local_library_rounded,
                        size: 34, color: cs.onPrimary),
                  ),
                  const SizedBox(height: 14),
                  Text('المكتبة العربية',
                      style: TextStyle(
                          color: cs.onPrimary,
                          fontSize: 22,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text('كتب اللغة العربية بصيغة PDF',
                      style: TextStyle(color: cs.onPrimary.withOpacity(0.85))),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                children: [
                  item('home', Icons.home_rounded, 'الشاشة الرئيسية', null),
                  item('library', Icons.menu_book_rounded, 'مكتبة اللغة العربية',
                      const ArabicLibraryScreen()),
                  item('settings', Icons.settings_rounded, 'الإعدادات',
                      const SettingsScreen()),
                  item('about', Icons.info_rounded, 'من نحن',
                      const AboutScreen()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
