import 'dart:async';

import 'package:flutter/material.dart';
import '../library_service.dart';
import '../user_data.dart';
import '../widgets/app_drawer.dart';
import 'pdf_reader_screen.dart';

/// ملحوظاتي: ملحوظات حرة + كل علامات الكتب في مكان واحد.
class NotesScreen extends StatelessWidget {
  const NotesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        drawer: const AppDrawer(current: 'notes'),
        appBar: AppBar(
          title: const Text('ملحوظاتي'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'ملحوظاتي'),
              Tab(text: 'علامات الكتب'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _NotesTab(),
            _BookmarksTab(),
          ],
        ),
      ),
    );
  }
}

// ───────────── تبويب الملحوظات ─────────────
class _NotesTab extends StatefulWidget {
  const _NotesTab();

  @override
  State<_NotesTab> createState() => _NotesTabState();
}

class _NotesTabState extends State<_NotesTab> {
  List<Note>? _notes;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final n = await NotesService.all();
    if (mounted) setState(() => _notes = n);
  }

  Future<void> _open(Note? note) async {
    await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => NoteEditorScreen(note: note)));
    _reload();
  }

  Future<void> _confirmDelete(Note n) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الملحوظة؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حذف')),
        ],
      ),
    );
    if (ok == true) {
      await NotesService.remove(n.id);
      _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    final notes = _notes;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _open(null),
        icon: const Icon(Icons.add_rounded),
        label: const Text('ملحوظة جديدة'),
      ),
      body: notes == null
          ? const Center(child: CircularProgressIndicator())
          : notes.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text('لا توجد ملحوظات بعد.\nاضغطي «ملحوظة جديدة» لتبدئي.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16)),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                  itemCount: notes.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final n = notes[i];
                    return Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                      child: ListTile(
                        title: Text(
                          n.title.isEmpty ? 'بدون عنوان' : n.title,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        subtitle: n.text.trim().isEmpty
                            ? null
                            : Text(n.text.trim(),
                                maxLines: 2, overflow: TextOverflow.ellipsis),
                        onTap: () => _open(n),
                        trailing: IconButton(
                          tooltip: 'حذف',
                          icon: const Icon(Icons.delete_outline_rounded),
                          onPressed: () => _confirmDelete(n),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}

// ───────────── محرر الملحوظة (يحفظ تلقائياً) ─────────────
class NoteEditorScreen extends StatefulWidget {
  final Note? note;
  const NoteEditorScreen({super.key, this.note});

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late final String _id = widget.note?.id ?? NotesService.newId();
  late final TextEditingController _title =
      TextEditingController(text: widget.note?.title ?? '');
  late final TextEditingController _text =
      TextEditingController(text: widget.note?.text ?? '');
  Future<void> _saving = Future<void>.value();
  bool _deleted = false;

  void _queueSave() {
    _saving = _saving.then((_) => _save());
  }

  Future<void> _save() async {
    if (_deleted) return;
    final t = _title.text.trim();
    final x = _text.text;
    if (t.isEmpty && x.trim().isEmpty) {
      await NotesService.remove(_id);
      return;
    }
    await NotesService.save(Note(
      id: _id,
      title: t,
      text: x,
      ts: DateTime.now().millisecondsSinceEpoch,
    ));
  }

  Future<void> _delete() async {
    _deleted = true;
    await _saving;
    await NotesService.remove(_id);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _title.dispose();
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.note == null ? 'ملحوظة جديدة' : 'تعديل الملحوظة'),
        actions: [
          IconButton(
            tooltip: 'حذف',
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: _delete,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _title,
              onChanged: (_) => _queueSave(),
              textInputAction: TextInputAction.next,
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                hintText: 'العنوان',
                border: InputBorder.none,
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: TextField(
                controller: _text,
                onChanged: (_) => _queueSave(),
                expands: true,
                maxLines: null,
                minLines: null,
                textAlignVertical: TextAlignVertical.top,
                style: const TextStyle(fontSize: 17, height: 1.6),
                decoration: const InputDecoration(
                  hintText: 'اكتبي ملحوظتك هنا... (تُحفظ تلقائياً)',
                  border: InputBorder.none,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ───────────── تبويب علامات كل الكتب ─────────────
class _BookmarksTab extends StatefulWidget {
  const _BookmarksTab();

  @override
  State<_BookmarksTab> createState() => _BookmarksTabState();
}

class _BookmarksTabState extends State<_BookmarksTab> {
  List<MapEntry<Book, List<Bookmark>>>? _groups;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final all = await BookmarksService.all();
    final books = await LibraryService.all();
    final byPath = {for (final b in books) b.path: b};
    final groups = <MapEntry<Book, List<Bookmark>>>[];
    all.forEach((path, list) {
      final book = byPath[path];
      if (book != null) groups.add(MapEntry(book, list));
    });
    groups.sort((a, b) => a.key.title.compareTo(b.key.title));
    if (mounted) setState(() => _groups = groups);
  }

  @override
  Widget build(BuildContext context) {
    final groups = _groups;
    if (groups == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (groups.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'لا توجد علامات بعد.\nأضيفي علامة من داخل أي كتاب بزر العلامة أعلى الشاشة.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16),
          ),
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: groups.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, i) {
        final book = groups[i].key;
        final marks = groups[i].value;
        return Card(
          elevation: 0,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Text(book.title,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                for (final m in marks)
                  ListTile(
                    dense: true,
                    leading: const Icon(Icons.bookmark_rounded),
                    title: Text(m.name),
                    subtitle: Text('صفحة ${m.page}'),
                    onTap: () async {
                      await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) =>
                              PdfReaderScreen(book: book, initialPage: m.page)));
                      _reload();
                    },
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
