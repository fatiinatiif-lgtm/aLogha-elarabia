import 'package:flutter/material.dart';
import '../design.dart';
import '../favorites.dart';
import '../library_service.dart';
import '../main.dart';
import '../widgets/app_drawer.dart';
import 'notes_screen.dart';
import 'pdf_reader_screen.dart';
import 'section_books_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      drawer: const AppDrawer(current: 'home'),
      appBar: AppBar(title: const Text('مكتبة اللغة العربية')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // الوضع الداكن
          Card(
            elevation: 0,
            color: cs.surfaceContainerHighest.withOpacity(0.6),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: SwitchListTile(
              secondary: Icon(
                  isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded),
              title: const Text('الوضع الداكن',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              value: isDark,
              onChanged: (v) => setDarkMode(v),
            ),
          ),
          const SizedBox(height: 14),

          // شريط البحث
          TextField(
            controller: _controller,
            onChanged: (v) => setState(() => _query = v),
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: 'ابحث في كل الكتب...',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () {
                        _controller.clear();
                        setState(() => _query = '');
                      },
                    ),
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),

          if (_query.trim().isNotEmpty)
            _SearchResults(query: _query)
          else ...[
            // ملحوظاتي
            InkWell(
              borderRadius: BorderRadius.circular(DesignStyle.of(context).radius + 4),
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const NotesScreen())),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(DesignStyle.of(context).radius + 4),
                  color: cs.surfaceContainerHighest,
                ),
                child: Row(
                  children: [
                    Icon(Icons.sticky_note_2_rounded,
                        size: 40, color: cs.primary),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('ملحوظاتي',
                              style: TextStyle(
                                  fontSize: 19, fontWeight: FontWeight.bold)),
                          SizedBox(height: 3),
                          Text('ملحوظاتك وعلامات كتبك في مكان واحد'),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 22),
            const Text('الأقسام',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _SectionsView(),
          ],
        ],
      ),
    );
  }
}

class _SearchResults extends StatelessWidget {
  final String query;
  const _SearchResults({required this.query});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Book>>(
      future: LibraryService.search(query),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final results = snap.data!;
        if (results.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: Text('لا توجد نتائج')),
          );
        }
        return Column(
          children: [
            for (final b in results)
              Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  leading: Icon(Icons.picture_as_pdf_rounded,
                      color: Theme.of(context).colorScheme.primary),
                  title: Text(b.title),
                  subtitle: Text(b.section.title),
                  trailing: FavButton(path: b.path),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => PdfReaderScreen(book: b))),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// الأقسام بأربع طرق عرض حسب التصميم المختار.
class _SectionsView extends StatelessWidget {
  void _open(BuildContext context, Section s) => Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SectionBooksScreen(section: s)));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final st = DesignStyle.of(context);
    final r = st.radius;
    switch (st.sectionLayout) {
      case SectionLayout.chips:
        return Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final s in sections)
              ActionChip(
                avatar: Icon(s.icon, size: 18, color: cs.primary),
                label: Text(s.title),
                onPressed: () => _open(context, s),
              ),
          ],
        );
      case SectionLayout.grid:
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.25,
          children: [
            for (final s in sections)
              InkWell(
                borderRadius: BorderRadius.circular(r),
                onTap: () => _open(context, s),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(r),
                    gradient: LinearGradient(
                      colors: [cs.primary, cs.primary.withOpacity(0.7)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(s.icon, size: 38, color: cs.onPrimary),
                      const SizedBox(height: 8),
                      Text(s.title,
                          style: TextStyle(
                              color: cs.onPrimary,
                              fontSize: 17,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ),
          ],
        );
      case SectionLayout.list:
        return Column(
          children: [
            for (final s in sections)
              Container(
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(r),
                  border: Border.all(color: cs.primary.withOpacity(0.5)),
                ),
                child: ListTile(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(r)),
                  leading: Icon(s.icon, color: cs.primary),
                  title: Text(s.title,
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w600)),
                  trailing:
                      const Icon(Icons.arrow_back_ios_new_rounded, size: 15),
                  onTap: () => _open(context, s),
                ),
              ),
          ],
        );
      case SectionLayout.carousel:
        return SizedBox(
          height: 150,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: sections.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              final s = sections[i];
              return InkWell(
                borderRadius: BorderRadius.circular(r),
                onTap: () => _open(context, s),
                child: Container(
                  width: 130,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(r),
                    color: cs.surfaceContainerHighest,
                    border: Border.all(color: cs.primary.withOpacity(0.35)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(s.icon, size: 40, color: cs.primary),
                      const SizedBox(height: 10),
                      Text(s.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              );
            },
          ),
        );
    }
  }
}
