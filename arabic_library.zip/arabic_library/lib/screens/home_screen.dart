import 'package:flutter/material.dart';
import '../library_service.dart';
import '../main.dart';
import '../widgets/app_drawer.dart';
import 'arabic_library_screen.dart';
import 'pdf_reader_screen.dart';
import 'section_books_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      drawer: const AppDrawer(current: 'home'),
      appBar: AppBar(title: const Text('المكتبة العربية')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // الوضع الداكن
          Card(
            elevation: 0,
            color: cs.surfaceContainerHighest.withOpacity(0.6),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
            child: SwitchListTile(
              secondary: Icon(
                  isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded),
              title: const Text('الوضع الداكن',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              value: isDark,
              onChanged: (v) => setDarkMode(v),
            ),
          ),
          const SizedBox(height: 14),

          // شريط البحث
          TextField(
            controller: _controller,
            onChanged: (v) => setState(() => _query = v),
            textInputAction: TextInputAction.search,
            decoration: InputDecoration(
              hintText: 'ابحث في كل الكتب...',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () {
                        _controller.clear();
                        setState(() => _query = '');
                      },
                    ),
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),

          if (_query.trim().isNotEmpty)
            _SearchResults(query: _query)
          else ...[
            // بطاقة مكتبة اللغة العربية
            InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const ArabicLibraryScreen())),
              child: Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: LinearGradient(
                    colors: [cs.primary, cs.primary.withOpacity(0.65)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(Icons.menu_book_rounded,
                        size: 54, color: cs.onPrimary),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('مكتبة اللغة العربية',
                              style: TextStyle(
                                  color: cs.onPrimary,
                                  fontSize: 21,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text('النحو والصرف والبلاغة والعروض وغيرها',
                              style: TextStyle(
                                  color: cs.onPrimary.withOpacity(0.9))),
                        ],
                      ),
                    ),
                    Icon(Icons.arrow_back_ios_new_rounded,
                        color: cs.onPrimary, size: 18),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 22),
            const Text('الأقسام',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                for (final s in sections)
                  ActionChip(
                    avatar: Icon(s.icon, size: 18, color: s.color),
                    label: Text(s.title),
                    onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (_) => SectionBooksScreen(section: s))),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _SearchResults extends StatelessWidget {
  final String query;
  const _SearchResults({required this.query});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Book>>(
      future: LibraryService.search(query),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final results = snap.data!;
        if (results.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(32),
            child: Center(child: Text('لا توجد نتائج')),
          );
        }
        return Column(
          children: [
            for (final b in results)
              Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  leading: Icon(Icons.picture_as_pdf_rounded,
                      color: b.section.color),
                  title: Text(b.title),
                  subtitle: Text(b.section.title),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => PdfReaderScreen(book: b))),
                ),
              ),
          ],
        );
      },
    );
  }
}
