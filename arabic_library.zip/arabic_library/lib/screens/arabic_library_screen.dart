import 'package:flutter/material.dart';
import '../library_service.dart';
import '../widgets/app_drawer.dart';
import 'section_books_screen.dart';

class ArabicLibraryScreen extends StatelessWidget {
  const ArabicLibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      drawer: const AppDrawer(current: 'library'),
      appBar: AppBar(title: const Text('مكتبة اللغة العربية')),
      body: FutureBuilder<List<Book>>(
        future: LibraryService.all(),
        builder: (context, snap) {
          final books = snap.data ?? [];
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              childAspectRatio: 1.05,
            ),
            itemCount: sections.length,
            itemBuilder: (context, i) {
              final s = sections[i];
              final count = books.where((b) => b.section.id == s.id).length;
              return InkWell(
                borderRadius: BorderRadius.circular(22),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => SectionBooksScreen(section: s))),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    gradient: LinearGradient(
                      colors: [cs.primary, cs.secondary],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                    ),
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(s.icon, size: 46, color: cs.onPrimary),
                      const SizedBox(height: 10),
                      Text(s.title,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: cs.onPrimary,
                              fontSize: 19,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text('$count كتاب',
                          style: TextStyle(color: cs.onPrimary.withOpacity(0.8))),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
