import 'package:flutter/material.dart';
import '../design.dart';
import '../library_service.dart';
import '../widgets/app_drawer.dart';
import 'section_books_screen.dart';

class ArabicLibraryScreen extends StatelessWidget {
  const ArabicLibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final r = DesignStyle.of(context).radius.clamp(14.0, 28.0).toDouble();
    return Scaffold(
      drawer: const AppDrawer(current: 'library'),
      appBar: AppBar(title: const Text('مكتبة اللغة العربية')),
      body: FutureBuilder<List<Book>>(
        future: LibraryService.all(),
        builder: (context, snap) {
          final books = snap.data ?? [];
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: sections.length,
            separatorBuilder: (_, __) => const SizedBox(height: 14),
            itemBuilder: (context, i) {
              final s = sections[i];
              final count = books.where((b) => b.section.id == s.id).length;
              return Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(r),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => SectionBooksScreen(section: s))),
                  child: Ink(
                    height: 96,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(r),
                      gradient: LinearGradient(
                        colors: [cs.primary, cs.primary.withOpacity(0.72)],
                        begin: Alignment.centerRight,
                        end: Alignment.centerLeft,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: cs.primary.withOpacity(0.25),
                          blurRadius: 12,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        // زخرفة خفيفة: أيقونة كبيرة شفافة في الخلفية
                        Positioned(
                          left: -14,
                          bottom: -22,
                          child: Icon(s.icon,
                              size: 120,
                              color: cs.onPrimary.withOpacity(0.10)),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Row(
                            children: [
                              Container(
                                width: 58,
                                height: 58,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: cs.onPrimary.withOpacity(0.16),
                                  border: Border.all(
                                      color: cs.onPrimary.withOpacity(0.35),
                                      width: 1.5),
                                ),
                                child:
                                    Icon(s.icon, size: 30, color: cs.onPrimary),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(s.title,
                                        style: TextStyle(
                                            color: cs.onPrimary,
                                            fontSize: 21,
                                            fontWeight: FontWeight.bold)),
                                    const SizedBox(height: 4),
                                    Text('$count كتاب',
                                        style: TextStyle(
                                            color:
                                                cs.onPrimary.withOpacity(0.85),
                                            fontSize: 14)),
                                  ],
                                ),
                              ),
                              Icon(Icons.arrow_back_ios_new_rounded,
                                  size: 18, color: cs.onPrimary),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
