import 'package:flutter/material.dart';
import '../library_service.dart';
import '../widgets/app_drawer.dart';
import 'section_books_screen.dart';

class ArabicLibraryScreen extends StatelessWidget {
  const ArabicLibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    const double size = 170;
    return Scaffold(
      drawer: const AppDrawer(current: 'library'),
      appBar: AppBar(title: const Text('مكتبة اللغة العربية')),
      body: FutureBuilder<List<Book>>(
        future: LibraryService.all(),
        builder: (context, snap) {
          final books = snap.data ?? [];
          // دوائر كبيرة تحت بعضها في المنتصف
          return ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            itemCount: sections.length,
            separatorBuilder: (_, __) => const SizedBox(height: 26),
            itemBuilder: (context, i) {
              final s = sections[i];
              final count = books.where((b) => b.section.id == s.id).length;
              return Center(
                child: Material(
                  color: Colors.transparent,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => SectionBooksScreen(section: s))),
                    child: Ink(
                      width: size,
                      height: size,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [cs.primary, cs.primary.withOpacity(0.7)],
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                        ),
                        border: Border.all(
                            color: cs.primary.withOpacity(0.25), width: 6),
                        boxShadow: [
                          BoxShadow(
                            color: cs.primary.withOpacity(0.28),
                            blurRadius: 16,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(22),
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(s.icon, size: 44, color: cs.onPrimary),
                              const SizedBox(height: 8),
                              Text(s.title,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: cs.onPrimary,
                                      fontSize: 21,
                                      fontWeight: FontWeight.bold)),
                              const SizedBox(height: 3),
                              Text('$count كتاب',
                                  style: TextStyle(
                                      color: cs.onPrimary.withOpacity(0.85),
                                      fontSize: 14)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
