import 'dart:async';
import 'dart:collection';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:pdfx/pdfx.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../library_service.dart';
import '../user_data.dart';

// ───────────── سرعة التمرير (متوسطة: 1.0 = السرعة العادية، زوّدي الرقم لو عايزة أسرع) ─────────────
const double kDragSpeed = 1.2; // سرعة الحركة مع الإصبع
const double kFlingSpeed = 1.1; // سرعة الانزلاق بعد رفع الإصبع

class _FastPhysics extends ClampingScrollPhysics {
  const _FastPhysics({super.parent});

  @override
  _FastPhysics applyTo(ScrollPhysics? ancestor) =>
      _FastPhysics(parent: buildParent(ancestor));

  @override
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) =>
      super.applyPhysicsToUserOffset(position, offset) * kDragSpeed;

  @override
  Simulation? createBallisticSimulation(
          ScrollMetrics position, double velocity) =>
      super.createBallisticSimulation(position, velocity * kFlingSpeed);
}

// ───────────── ألوان راحة العين للقراءة ─────────────
class ComfortPreset {
  final String name;
  final Color? tint; // لون الورق
  final BlendMode? blend;
  final Color? bg; // خلفية الشاشة حول الصفحات
  const ComfortPreset(this.name, this.tint, this.blend, this.bg);
}

const List<ComfortPreset> kComfortPresets = [
  ComfortPreset('الأصلي', null, null, null),
  ComfortPreset('ورق دافئ', Color(0xFFF1E5C8), BlendMode.multiply, Color(0xFFF1E5C8)),
  ComfortPreset('كريمي', Color(0xFFF8F1DE), BlendMode.multiply, Color(0xFFF8F1DE)),
  ComfortPreset('سيبيا', Color(0xFFE6D2A8), BlendMode.multiply, Color(0xFFE6D2A8)),
  ComfortPreset('أخضر مريح', Color(0xFFD5E8D0), BlendMode.multiply, Color(0xFFD5E8D0)),
  ComfortPreset('أزرق هادئ', Color(0xFFD3E4F2), BlendMode.multiply, Color(0xFFD3E4F2)),
  ComfortPreset('رمادي ناعم', Color(0xFFDDDDDD), BlendMode.multiply, Color(0xFFDDDDDD)),
  ComfortPreset('وردي فاتح', Color(0xFFF4DDE0), BlendMode.multiply, Color(0xFFF4DDE0)),
  ComfortPreset('ليلي', Color(0xFFEFEDEA), BlendMode.difference, Color(0xFF101215)),
  ComfortPreset('ليلي دافئ', Color(0xFFE8DCC0), BlendMode.difference, Color(0xFF14100A)),
  ComfortPreset('ليلي أزرق', Color(0xFFC8D8EE), BlendMode.difference, Color(0xFF0B1018)),
];

// ───────────── تحميل الصفحات بسرعة (طابور واحد + ذاكرة مؤقتة) ─────────────
class _Rendered {
  final Uint8List bytes;
  final double ratio; // العرض ÷ الارتفاع
  const _Rendered(this.bytes, this.ratio);
}

class _PageLoader {
  final PdfDocument doc;
  final double renderWidth;
  _PageLoader(this.doc, this.renderWidth);

  static const _maxCache = 40;
  bool _closed = false;
  int _pending = 0;
  Future<void> _tail = Future<void>.value();
  final LinkedHashMap<int, _Rendered> _cache = LinkedHashMap<int, _Rendered>();
  final Map<int, Future<_Rendered?>> _inflight = {};
  final Map<int, int> _wanted = {};

  _Rendered? peek(int page) {
    final r = _cache.remove(page);
    if (r != null) _cache[page] = r;
    return r;
  }

  Future<_Rendered?> request(int page) {
    _wanted[page] = (_wanted[page] ?? 0) + 1;
    final hit = peek(page);
    if (hit != null) return Future<_Rendered?>.value(hit);
    return _inflight[page] ??= _run(page, force: false);
  }

  void release(int page) {
    final n = (_wanted[page] ?? 1) - 1;
    if (n <= 0) {
      _wanted.remove(page);
    } else {
      _wanted[page] = n;
    }
  }

  /// تحميل مسبق للصفحة التالية عندما يكون الطابور فاضي.
  void prefetch(int page) {
    if (_closed || _pending > 0) return;
    if (page < 1 || page > doc.pagesCount) return;
    if (_cache.containsKey(page) || _inflight.containsKey(page)) return;
    _inflight[page] = _run(page, force: true);
  }

  Future<_Rendered?> _run(int page, {required bool force}) {
    final c = Completer<_Rendered?>();
    _pending++;
    _tail = _tail.then((_) async {
      try {
        // لو الصفحة خرجت من الشاشة قبل دورها نتخطاها
        if (_closed || (!force && (_wanted[page] ?? 0) <= 0)) {
          c.complete(null);
        } else {
          c.complete(await _render(page));
        }
      } catch (_) {
        c.complete(null);
      }
    });
    return c.future.whenComplete(() {
      _pending--;
      _inflight.remove(page);
    });
  }

  Future<_Rendered?> _render(int page) async {
    final p = await doc.getPage(page);
    try {
      final ratio = p.width / p.height;
      final w = renderWidth;
      final img = await p.render(
        width: w,
        height: w / ratio,
        format: PdfPageImageFormat.jpeg,
        backgroundColor: '#FFFFFF',
        quality: 85,
      );
      if (img == null) return null;
      final r = _Rendered(img.bytes, ratio);
      _cache[page] = r;
      while (_cache.length > _maxCache) {
        _cache.remove(_cache.keys.first);
      }
      return r;
    } finally {
      await p.close();
    }
  }

  void close() {
    _closed = true;
    _tail.whenComplete(() => doc.close());
  }
}

// ───────────── صفحة واحدة ─────────────
class _PageTile extends StatefulWidget {
  final _PageLoader loader;
  final int page; // يبدأ من 1
  final double width;
  final double ratio;
  final Color? tint;
  final BlendMode? blend;
  final void Function(int page, double ratio) onRatio;

  const _PageTile({
    super.key,
    required this.loader,
    required this.page,
    required this.width,
    required this.ratio,
    required this.tint,
    required this.blend,
    required this.onRatio,
  });

  @override
  State<_PageTile> createState() => _PageTileState();
}

class _PageTileState extends State<_PageTile> {
  _Rendered? _data;
  int _tries = 0;

  @override
  void initState() {
    super.initState();
    _data = widget.loader.peek(widget.page);
    if (_data == null) {
      _load();
    } else {
      widget.loader.request(widget.page); // لتسجيل أن الصفحة مطلوبة
      _afterReady();
    }
  }

  Future<void> _load() async {
    final r = await widget.loader.request(widget.page);
    if (!mounted) return;
    if (r == null) {
      if (_tries++ < 3) {
        await Future<void>.delayed(const Duration(milliseconds: 250));
        if (mounted) {
          widget.loader.release(widget.page);
          _load();
        }
      }
      return;
    }
    setState(() => _data = r);
    _afterReady();
  }

  void _afterReady() {
    final r = _data;
    if (r == null) return;
    if ((r.ratio - widget.ratio).abs() > 0.002) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) widget.onRatio(widget.page, r.ratio);
      });
    }
    widget.loader.prefetch(widget.page + 1);
  }

  @override
  void dispose() {
    widget.loader.release(widget.page);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = _data;
    final height = widget.width / (r?.ratio ?? widget.ratio);
    return SizedBox(
      width: widget.width,
      height: height,
      child: r == null
          ? const ColoredBox(
              color: Colors.white,
              child: Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            )
          : Image.memory(
              r.bytes,
              fit: BoxFit.fill,
              gaplessPlayback: true,
              filterQuality: FilterQuality.medium,
              color: widget.tint,
              colorBlendMode: widget.blend,
            ),
    );
  }
}

// ───────────── شاشة القراءة ─────────────
class PdfReaderScreen extends StatefulWidget {
  final Book book;
  final int initialPage; // يبدأ من 1
  const PdfReaderScreen({super.key, required this.book, this.initialPage = 1});

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> {
  static const _prefComfort = 'comfort_mode'; // قديم (تشغيل/إيقاف)
  static const _prefPreset = 'comfort_preset';
  static const double _thumbH = 46;

  _PageLoader? _loader;
  Object? _error;
  bool _started = false;
  int _count = 0;
  double _defaultRatio = 0.707;
  final Map<int, double> _ratios = {};

  final ItemScrollController _scroll = ItemScrollController();
  final ItemPositionsListener _positions = ItemPositionsListener.create();

  final ValueNotifier<int> _page = ValueNotifier<int>(1);
  final ValueNotifier<double> _fraction = ValueNotifier<double>(0);
  final ValueNotifier<bool> _thumbVisible = ValueNotifier<bool>(false);
  bool _dragging = false;
  double _dragFraction = 0;
  Timer? _hideTimer;

  int _preset = 0; // 0 = بدون تغيير للألوان

  @override
  void initState() {
    super.initState();
    _page.value = widget.initialPage;
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    var p = prefs.getInt(_prefPreset);
    if (p == null) {
      // من النسخة القديمة: لو كان الوضع مفعّلاً نختار ورق دافئ أو ليلي
      final old = prefs.getBool(_prefComfort) ?? false;
      final dark = Theme.of(context).brightness == Brightness.dark;
      p = old ? (dark ? 8 : 1) : 0;
    }
    setState(() => _preset = p!.clamp(0, kComfortPresets.length - 1).toInt());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_started) {
      _started = true;
      _open();
    }
  }

  Future<void> _open() async {
    try {
      final media = MediaQuery.of(context);
      final rw = (media.size.width * media.devicePixelRatio)
          .clamp(700.0, 1700.0)
          .toDouble();
      final doc = await PdfDocument.openAsset(widget.book.path);
      final first = await doc.getPage(1);
      final ratio = first.width / first.height;
      await first.close();
      if (!mounted) {
        await doc.close();
        return;
      }
      _positions.itemPositions.addListener(_onScroll);
      setState(() {
        _loader = _PageLoader(doc, rw);
        _count = doc.pagesCount;
        _defaultRatio = ratio;
      });
    } catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _positions.itemPositions.removeListener(_onScroll);
    _loader?.close();
    _page.dispose();
    _fraction.dispose();
    _thumbVisible.dispose();
    super.dispose();
  }

  // ── تتبع التمرير: رقم الصفحة + مكان العلامة الجانبية ──
  void _onScroll() {
    final positions = _positions.itemPositions.value;
    if (positions.isEmpty || _count == 0) return;

    ItemPosition? first;
    for (final p in positions) {
      if (p.itemTrailingEdge > 0.12 && (first == null || p.index < first.index)) {
        first = p;
      }
    }
    first ??= positions.first;

    var pos = first.index.toDouble();
    final span = first.itemTrailingEdge - first.itemLeadingEdge;
    if (span > 0 && first.itemLeadingEdge < 0) {
      pos += (-first.itemLeadingEdge / span).clamp(0.0, 1.0).toDouble();
    }
    var fraction = _count <= 1 ? 0.0 : pos / (_count - 1);
    for (final p in positions) {
      if (p.index == _count - 1 && p.itemTrailingEdge <= 1.001) fraction = 1.0;
    }
    fraction = fraction.clamp(0.0, 1.0).toDouble();

    _page.value = first.index + 1;
    if (!_dragging) _fraction.value = fraction;

    // تظهر العلامة مع التمرير وتختفي بعد التوقف
    _thumbVisible.value = true;
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(milliseconds: 900), () {
      if (mounted && !_dragging) _thumbVisible.value = false;
    });
  }

  void _jumpToPage(int page) {
    if (_count == 0) return;
    final i = (page - 1).clamp(0, _count - 1).toInt();
    _scroll.jumpTo(index: i);
  }

  void _step(int delta) {
    if (_count == 0) return;
    final target = (_page.value - 1 + delta).clamp(0, _count - 1).toInt();
    _scroll.scrollTo(
      index: target,
      duration: const Duration(milliseconds: 140),
      curve: Curves.easeOut,
    );
  }

  Future<void> _setPreset(int i) async {
    setState(() => _preset = i);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefPreset, i);
  }

  Future<void> _showComfortPicker() async {
    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('ألوان راحة العين',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              Wrap(
                spacing: 12,
                runSpacing: 14,
                children: [
                  for (var i = 0; i < kComfortPresets.length; i++)
                    InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () {
                        _setPreset(i);
                        Navigator.of(ctx).pop();
                      },
                      child: SizedBox(
                        width: 72,
                        child: Column(
                          children: [
                            Container(
                              width: 56,
                              height: 56,
                              decoration: BoxDecoration(
                                // معاينة: لون الخلفية الناتجة
                                color: kComfortPresets[i].bg ?? Colors.white,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: i == _preset
                                      ? Theme.of(ctx).colorScheme.primary
                                      : Colors.grey,
                                  width: i == _preset ? 3 : 1,
                                ),
                              ),
                              child: Icon(
                                Icons.text_fields_rounded,
                                color: kComfortPresets[i].blend ==
                                        BlendMode.difference
                                    ? Colors.white70
                                    : Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(kComfortPresets[i].name,
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 12.5)),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── الذهاب إلى صفحة ──
  Future<void> _goToPageDialog() async {
    final ctrl = TextEditingController();
    final result = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('الذهاب إلى صفحة'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(hintText: '١ - $_count'),
          onSubmitted: (v) => Navigator.pop(ctx, int.tryParse(v.trim())),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () =>
                  Navigator.pop(ctx, int.tryParse(ctrl.text.trim())),
              child: const Text('اذهب')),
        ],
      ),
    );
    if (result != null) _jumpToPage(result);
  }

  // ── العلامات ──
  Future<String?> _askName(String title, String initial) async {
    final ctrl = TextEditingController(text: initial);
    ctrl.selection = TextSelection(baseOffset: 0, extentOffset: initial.length);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'اسم العلامة'),
          onSubmitted: (v) => Navigator.pop(ctx, v.trim()),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: const Text('حفظ')),
        ],
      ),
    );
  }

  Future<void> _addBookmark() async {
    final page = _page.value;
    final name = await _askName('علامة جديدة', 'صفحة $page');
    if (name == null) return;
    await BookmarksService.add(
        widget.book.path, page, name.isEmpty ? 'صفحة $page' : name);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت إضافة علامة عند صفحة $page'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _showBookmarks() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setSheet) {
          return SafeArea(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(ctx).size.height * 0.7),
              child: FutureBuilder<List<Bookmark>>(
                future: BookmarksService.of(widget.book.path),
                builder: (ctx, snap) {
                  final list = snap.data ?? [];
                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                        child: FilledButton.icon(
                          icon: const Icon(Icons.bookmark_add_rounded),
                          label: Text('إضافة علامة عند صفحة ${_page.value}'),
                          onPressed: () async {
                            final page = _page.value;
                            final name =
                                await _askName('علامة جديدة', 'صفحة $page');
                            if (name == null) return;
                            await BookmarksService.add(widget.book.path, page,
                                name.isEmpty ? 'صفحة $page' : name);
                            setSheet(() {});
                          },
                        ),
                      ),
                      if (list.isEmpty && snap.connectionState == ConnectionState.done)
                        const Padding(
                          padding: EdgeInsets.all(28),
                          child: Text('لا توجد علامات في هذا الكتاب بعد'),
                        )
                      else
                        Flexible(
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: list.length,
                            itemBuilder: (ctx, i) {
                              final b = list[i];
                              return ListTile(
                                leading: const Icon(Icons.bookmark_rounded),
                                title: Text(b.name),
                                subtitle: Text('صفحة ${b.page}'),
                                onTap: () {
                                  Navigator.pop(ctx);
                                  _jumpToPage(b.page);
                                },
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      tooltip: 'تسمية',
                                      icon: const Icon(Icons.edit_rounded),
                                      onPressed: () async {
                                        final name = await _askName(
                                            'تسمية العلامة', b.name);
                                        if (name == null || name.isEmpty) return;
                                        await BookmarksService.rename(
                                            widget.book.path, b.id, name);
                                        setSheet(() {});
                                      },
                                    ),
                                    IconButton(
                                      tooltip: 'حذف',
                                      icon: const Icon(Icons.delete_outline_rounded),
                                      onPressed: () async {
                                        await BookmarksService.remove(
                                            widget.book.path, b.id);
                                        setSheet(() {});
                                      },
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),
          );
        });
      },
    );
  }

  // ── البناء ──
  @override
  Widget build(BuildContext context) {

    // ألوان راحة العين: المستخدمة تختار من القائمة
    final preset = kComfortPresets[_preset];
    final Color? tint = preset.tint;
    final BlendMode? blend = preset.blend;
    final Color? bg = preset.bg;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        title: Text(widget.book.title,
            overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17)),
        actions: [
          ValueListenableBuilder<int>(
            valueListenable: _page,
            builder: (_, p, __) => TextButton(
              onPressed: _goToPageDialog,
              child: Text(
                '$p / $_count',
                textDirection: TextDirection.ltr,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ),
          IconButton(
            tooltip: 'إضافة علامة',
            icon: const Icon(Icons.bookmark_add_outlined),
            onPressed: _count == 0 ? null : _addBookmark,
          ),
          IconButton(
            tooltip: 'علاماتي في الكتاب',
            icon: const Icon(Icons.bookmarks_outlined),
            onPressed: _showBookmarks,
          ),
          IconButton(
            tooltip: 'ألوان راحة العين',
            icon: Icon(_preset != 0
                ? Icons.wb_sunny_rounded
                : Icons.wb_sunny_outlined),
            onPressed: _showComfortPicker,
          ),
        ],
      ),
      body: _buildBody(tint, blend),
      bottomNavigationBar: SafeArea(
        child: SizedBox(
          height: 52,
          child: Row(
            children: [
              Expanded(
                child: IconButton(
                  tooltip: 'صفحة للأعلى',
                  iconSize: 32,
                  icon: const Icon(Icons.keyboard_arrow_up_rounded),
                  onPressed: () => _step(-1),
                ),
              ),
              Expanded(
                child: IconButton(
                  tooltip: 'صفحة للأسفل',
                  iconSize: 32,
                  icon: const Icon(Icons.keyboard_arrow_down_rounded),
                  onPressed: () => _step(1),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBody(Color? tint, BlendMode? blend) {
    if (_error != null) {
      return const Center(child: Text('تعذّر فتح الكتاب'));
    }
    final loader = _loader;
    if (loader == null) {
      return const Center(child: CircularProgressIndicator());
    }

    final width = MediaQuery.of(context).size.width;
    final start = (widget.initialPage - 1).clamp(0, _count - 1).toInt();

    return Directionality(
      textDirection: TextDirection.ltr,
      child: Stack(
        children: [
          Positioned.fill(
            // لا تكبير ولا فواصل: صفحات متلاصقة بعرض الشاشة
            child: ScrollablePositionedList.builder(
              itemCount: _count,
              initialScrollIndex: start,
              itemScrollController: _scroll,
              itemPositionsListener: _positions,
              physics: const _FastPhysics(),
              itemBuilder: (context, i) {
                final page = i + 1;
                return _PageTile(
                  key: ValueKey(page),
                  loader: loader,
                  page: page,
                  width: width,
                  ratio: _ratios[page] ?? _defaultRatio,
                  tint: tint,
                  blend: blend,
                  onRatio: (p, r) {
                    if (!mounted) return;
                    setState(() => _ratios[p] = r);
                  },
                );
              },
            ),
          ),
          Positioned.fill(child: _buildThumb()),
        ],
      ),
    );
  }

  // العلامة الجانبية: تتحرك مع الكتاب، تظهر وقت التمرير وتختفي عند الوقوف
  Widget _buildThumb() {
    return LayoutBuilder(builder: (context, box) {
      final track = (box.maxHeight - _thumbH).clamp(1.0, double.infinity).toDouble();
      final cs = Theme.of(context).colorScheme;
      return AnimatedBuilder(
        animation: Listenable.merge([_fraction, _thumbVisible, _page]),
        builder: (context, _) {
          final visible = _thumbVisible.value || _dragging;
          return Stack(
            children: [
              Positioned(
                right: 0,
                top: _fraction.value * track,
                child: IgnorePointer(
                  ignoring: !visible,
                  child: AnimatedOpacity(
                    opacity: visible ? 1 : 0,
                    duration: const Duration(milliseconds: 220),
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onVerticalDragStart: (_) {
                        _dragging = true;
                        _dragFraction = _fraction.value;
                        _hideTimer?.cancel();
                        _thumbVisible.value = true;
                      },
                      onVerticalDragUpdate: (d) {
                        _dragFraction =
                            (_dragFraction + d.delta.dy / track).clamp(0.0, 1.0).toDouble();
                        _fraction.value = _dragFraction;
                        _jumpToPage((_dragFraction * (_count - 1)).round() + 1);
                      },
                      onVerticalDragEnd: (_) {
                        _dragging = false;
                        _hideTimer?.cancel();
                        _hideTimer = Timer(const Duration(milliseconds: 900), () {
                          if (mounted) _thumbVisible.value = false;
                        });
                      },
                      child: Container(
                        width: 58,
                        height: _thumbH,
                        alignment: Alignment.centerRight,
                        child: Container(
                          width: 46,
                          height: 30,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: cs.primary.withAlpha(215),
                            borderRadius: const BorderRadius.horizontal(
                                left: Radius.circular(15)),
                          ),
                          child: Text(
                            '${_page.value}',
                            style: TextStyle(
                              color: cs.onPrimary,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      );
    });
  }
}
