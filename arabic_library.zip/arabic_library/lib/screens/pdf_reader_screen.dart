import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import '../library_service.dart';

class PdfReaderScreen extends StatefulWidget {
  final Book book;
  const PdfReaderScreen({super.key, required this.book});

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> {
  late final PdfControllerPinch _controller = PdfControllerPinch(
    document: PdfDocument.openAsset(widget.book.path),
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.book.title, overflow: TextOverflow.ellipsis),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Center(
              child: PdfPageNumber(
                controller: _controller,
                builder: (_, state, page, pagesCount) => Text(
                  '$page / ${pagesCount ?? 0}',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Directionality(
        textDirection: TextDirection.ltr,
        child: PdfViewPinch(controller: _controller),
      ),
    );
  }
}
