import 'package:flutter/material.dart';
import '../widgets/app_drawer.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      drawer: const AppDrawer(current: 'about'),
      appBar: AppBar(title: const Text('من نحن')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 10),
          Center(
            child: CircleAvatar(
              radius: 46,
              backgroundColor: cs.primaryContainer,
              child: Icon(Icons.local_library_rounded,
                  size: 52, color: cs.primary),
            ),
          ),
          const SizedBox(height: 18),
          const Center(
            child: Text('المكتبة العربية',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 18),
          const Text(
            'تطبيق يجمع كتب اللغة العربية بصيغة PDF في مكان واحد: '
            'النحو، والصرف، والبلاغة، والعروض، والأدب العربي، وفقه اللغة، '
            'ليكون عوناً للطلاب والباحثين ومحبي العربية.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, height: 1.8),
          ),
        ],
      ),
    );
  }
}
