import 'package:flutter/material.dart';
import '../main.dart';
import '../widgets/app_drawer.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      drawer: const AppDrawer(current: 'settings'),
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            child: SwitchListTile(
              secondary: Icon(
                  isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded),
              title: const Text('الوضع الداكن'),
              subtitle: const Text('مريح للعين في الإضاءة المنخفضة'),
              value: isDark,
              onChanged: (v) => setDarkMode(v),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            child: const ListTile(
              leading: Icon(Icons.info_outline_rounded),
              title: Text('إصدار التطبيق'),
              trailing: Text('1.0.0', textDirection: TextDirection.ltr),
            ),
          ),
        ],
      ),
    );
  }
}
