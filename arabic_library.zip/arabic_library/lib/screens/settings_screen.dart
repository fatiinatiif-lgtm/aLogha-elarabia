import 'package:flutter/material.dart';
import '../design.dart';
import '../main.dart';
import '../widgets/app_drawer.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final style = DesignStyle.of(context);
    final shape =
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(style.radius));
    return Scaffold(
      drawer: const AppDrawer(current: 'settings'),
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: shape,
            child: SwitchListTile(
              secondary: Icon(
                  isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded),
              title: const Text('الوضع الداكن'),
              subtitle: const Text('مريح للعين في الإضاءة المنخفضة'),
              value: isDark,
              onChanged: (v) => setDarkMode(v),
            ),
          ),
          const SizedBox(height: 22),
          const Text('تصميم التطبيق',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('كل تصميم له ألوانه وشكله وطريقة عرض الأقسام والكتب'),
          const SizedBox(height: 12),
          ValueListenableBuilder<AppDesign>(
            valueListenable: designNotifier,
            builder: (context, current, _) => Column(
              children: [
                for (final d in designs)
                  _DesignCard(
                      design: d, selected: d.id == current.id, dark: isDark),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Card(
            elevation: 0,
            shape: shape,
            child: const ListTile(
              leading: Icon(Icons.info_outline_rounded),
              title: Text('إصدار التطبيق'),
              trailing: Text('1.0.0', textDirection: TextDirection.ltr),
            ),
          ),
        ],
      ),
    );
  }
}

class _DesignCard extends StatelessWidget {
  final AppDesign design;
  final bool selected;
  final bool dark;
  const _DesignCard(
      {required this.design, required this.selected, required this.dark});

  IconData get _layoutIcon {
    switch (design.sectionLayout) {
      case SectionLayout.chips:
        return Icons.label_outline_rounded;
      case SectionLayout.grid:
        return Icons.grid_view_rounded;
      case SectionLayout.list:
        return Icons.view_list_rounded;
      case SectionLayout.carousel:
        return Icons.view_carousel_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final scheme = dark ? design.dark : design.light;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(design.radius),
        onTap: () => setDesign(design),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(design.radius),
            color: cs.surfaceContainerHighest.withOpacity(0.5),
            border: Border.all(
                color: selected ? cs.primary : Colors.transparent, width: 2),
          ),
          child: Row(
            children: [
              // معاينة مصغّرة: الألوان + شكل العرض
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: scheme.surface,
                  borderRadius: BorderRadius.circular(design.radius.clamp(8.0, 18.0).toDouble()),
                  border: Border.all(color: cs.outline.withOpacity(0.4)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(_layoutIcon, color: scheme.primary, size: 26),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _dot(scheme.primary),
                        _dot(scheme.secondary),
                        _dot(scheme.surfaceContainerHighest),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(design.name,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 3),
                    Text(design.description),
                  ],
                ),
              ),
              if (selected)
                Icon(Icons.check_circle_rounded, color: cs.primary),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dot(Color c) => Container(
        width: 11,
        height: 11,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
            color: c,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.black26, width: 0.5)),
      );
}
