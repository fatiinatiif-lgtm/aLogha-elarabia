import 'package:flutter/material.dart';
import '../design.dart';
import '../favorites.dart';
import '../library_service.dart';
import '../widgets/app_drawer.dart';
import 'pdf_reader_screen.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final r = DesignStyle.of(context).radius.clamp(6.0, 20.0).toDouble();
    return Scaffold(
      drawer: const AppDrawer(current: 'favorites'),
      appBar: AppBar(title: const Text('المفضلة')),
      body: FutureBuilder<List<Book>>(
        future: LibraryService.all(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final all = snap.data!;
          return ValueListenableBuilder<List<String>>(
            valueListenable: Favorites.notifier,
            builder: (context, favs, _) {
              final byPath = {for (final b in all) b.path: b};
              final books = [
                for (final p in favs)
                  if (byPath[p] != null) byPath[p]!
              ];
              if (books.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.favorite_border_rounded,
                            size: 76, color: cs.primary.withOpacity(0.4)),
                        const SizedBox(height: 16),
                        const Text('لا توجد كتب في المفضلة بعد',
                            style: TextStyle(fontSize: 18)),
                        const SizedBox(height: 8),
                        const Text('اضغطي على ♡ بجانب أي كتاب لإضافته هنا',
                            textAlign: TextAlign.center),
                      ],
                    ),
                  ),
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: books.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) {
                  final b = books[i];
                  return Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(r)),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 6),
                      leading: CircleAvatar(
                        backgroundColor: cs.primaryContainer,
                        child: Icon(Icons.picture_as_pdf_rounded,
                            color: cs.onPrimaryContainer),
                      ),
                      title: Text(b.title,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(b.section.title),
                      trailing: FavButton(path: b.path),
                      onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => PdfReaderScreen(book: b))),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
