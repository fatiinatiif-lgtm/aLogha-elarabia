import 'package:flutter/material.dart';
import '../design.dart';
import '../library_service.dart';
import 'pdf_reader_screen.dart';

class SectionBooksScreen extends StatefulWidget {
  final Section section;
  const SectionBooksScreen({super.key, required this.section});

  @override
  State<SectionBooksScreen> createState() => _SectionBooksScreenState();
}

class _SectionBooksScreenState extends State<SectionBooksScreen> {
  List<Book>? _books;
  bool _editing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final b = await LibraryService.booksOf(widget.section);
    if (mounted) setState(() => _books = b);
  }

  void _open(Book b) => Navigator.of(context)
      .push(MaterialPageRoute(builder: (_) => PdfReaderScreen(book: b)));

  Future<void> _reset() async {
    await LibraryService.resetOrder(widget.section);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final section = widget.section;
    final cs = Theme.of(context).colorScheme;
    final books = _books;
    return Scaffold(
      appBar: AppBar(
        title: Text(section.title),
        actions: [
          if (books != null && books.length > 1) ...[
            if (_editing)
              IconButton(
                tooltip: 'الترتيب الأصلي',
                icon: const Icon(Icons.restart_alt_rounded),
                onPressed: _reset,
              ),
            IconButton(
              tooltip: _editing ? 'تم' : 'ترتيب الكتب',
              icon: Icon(_editing ? Icons.check_rounded : Icons.swap_vert_rounded),
              onPressed: () => setState(() => _editing = !_editing),
            ),
          ],
        ],
      ),
      body: books == null
          ? const Center(child: CircularProgressIndicator())
          : books.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(section.icon,
                            size: 70, color: cs.primary.withOpacity(0.4)),
                        const SizedBox(height: 16),
                        const Text('لا توجد كتب في هذا القسم بعد',
                            style: TextStyle(fontSize: 18)),
                        const SizedBox(height: 8),
                        Text(
                          'أضيفي ملفات PDF داخل المجلد:\nassets/books/${section.id}/',
                          textAlign: TextAlign.center,
                          textDirection: TextDirection.ltr,
                        ),
                      ],
                    ),
                  ),
                )
              : Column(
                  children: [
                    if (_editing)
                      Container(
                        width: double.infinity,
                        color: cs.primaryContainer.withOpacity(0.6),
                        padding: const EdgeInsets.all(10),
                        child: const Text(
                          'اسحبي الكتاب من المقبض ☰ لتغيير مكانه، ثم اضغطي ✓',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    Expanded(
                      child: ReorderableListView.builder(
                        padding: const EdgeInsets.all(16),
                        buildDefaultDragHandles: false,
                        itemCount: books.length,
                        onReorder: (oldI, newI) {
                          if (newI > oldI) newI -= 1;
                          setState(() => books.insert(newI, books.removeAt(oldI)));
                          LibraryService.saveOrder(section, books);
                        },
                        itemBuilder: (context, i) => _BookTile(
                          key: ValueKey(books[i].path),
                          book: books[i],
                          index: i,
                          editing: _editing,
                          onTap: () => _open(books[i]),
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}

class _BookTile extends StatelessWidget {
  final Book book;
  final int index;
  final bool editing;
  final VoidCallback onTap;
  const _BookTile(
      {super.key,
      required this.book,
      required this.index,
      required this.editing,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final st = DesignStyle.of(context);
    final radius = BorderRadius.circular(st.radius.clamp(6, 20).toDouble());

    final tile = ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      leading: CircleAvatar(
        backgroundColor: cs.primaryContainer,
        child: Icon(Icons.picture_as_pdf_rounded, color: cs.onPrimaryContainer),
      ),
      title: Text(book.title, style: const TextStyle(fontWeight: FontWeight.w600)),
      trailing: editing
          ? ReorderableDragStartListener(
              index: index,
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: Icon(Icons.drag_handle_rounded),
              ),
            )
          : const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
      onTap: editing ? null : onTap,
    );

    Widget body;
    switch (st.bookTile) {
      case BookTileStyle.outlined:
        body = Card(
          elevation: 0,
          color: Colors.transparent,
          shape: RoundedRectangleBorder(
              borderRadius: radius,
              side: BorderSide(color: cs.primary.withOpacity(0.5))),
          child: tile,
        );
        break;
      case BookTileStyle.flat:
        body = Container(
          decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: cs.outline.withOpacity(0.25))),
          ),
          child: tile,
        );
        break;
      case BookTileStyle.card:
        body = Card(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: radius),
          child: tile,
        );
    }
    return Padding(
      padding: EdgeInsets.only(bottom: st.bookTile == BookTileStyle.flat ? 0 : 10),
      child: body,
    );
  }
}
