import 'package:flutter/material.dart';
import '../library_service.dart';
import 'pdf_reader_screen.dart';

class SectionBooksScreen extends StatelessWidget {
  final Section section;
  const SectionBooksScreen({super.key, required this.section});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(section.title)),
      body: FutureBuilder<List<Book>>(
        future: LibraryService.booksOf(section),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final books = snap.data!;
          if (books.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(section.icon,
                        size: 70, color: section.color.withOpacity(0.5)),
                    const SizedBox(height: 16),
                    const Text('لا توجد كتب في هذا القسم بعد',
                        style: TextStyle(fontSize: 18)),
                    const SizedBox(height: 8),
                    Text(
                      'أضيفي ملفات PDF داخل المجلد:\nassets/books/${section.id}/',
                      textAlign: TextAlign.center,
                      textDirection: TextDirection.ltr,
                    ),
                  ],
                ),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: books.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final b = books[i];
              return Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  leading: CircleAvatar(
                    backgroundColor: section.color.withOpacity(0.15),
                    child: Icon(Icons.picture_as_pdf_rounded,
                        color: section.color),
                  ),
                  title: Text(b.title,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  trailing: const Icon(Icons.arrow_back_ios_new_rounded,
                      size: 16),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => PdfReaderScreen(book: b))),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
