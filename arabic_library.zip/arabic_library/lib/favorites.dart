import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// الكتب المفضلة: تُحفظ في الجهاز بترتيب الإضافة.
class Favorites {
  static const _key = 'favorites';
  static final ValueNotifier<List<String>> notifier = ValueNotifier([]);

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    notifier.value = prefs.getStringList(_key) ?? [];
  }

  static bool isFav(String path) => notifier.value.contains(path);

  static Future<void> toggle(String path) async {
    final list = [...notifier.value];
    if (!list.remove(path)) list.add(path);
    notifier.value = list;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_key, list);
  }
}

/// نجمة المفضلة بجانب الكتاب.
class FavButton extends StatelessWidget {
  final String path;
  const FavButton({super.key, required this.path});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<List<String>>(
      valueListenable: Favorites.notifier,
      builder: (context, list, _) {
        final fav = list.contains(path);
        return IconButton(
          tooltip: fav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة',
          visualDensity: VisualDensity.compact,
          icon: Icon(
            fav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
            color: fav ? const Color(0xFFE53935) : null,
          ),
          onPressed: () => Favorites.toggle(path),
        );
      },
    );
  }
}
